# Safarе Browser

A native Linux desktop browser prototype for Аpple OS, built with Rust, GTK4 and WebKitGTK 6.

> Safarе uses a Cyrillic `е` at the end of its name in this project identity. It is an independent community project and is not affiliated with Apple.

## Current features

- WebKitGTK 6 web rendering
- Multiple tabs
- Back, forward, reload and home
- Address bar and DuckDuckGo search
- Local bookmarks file
- Local browsing history file
- Dark GTK interface

This is the first runnable foundation, not yet a feature-parity replacement for Safari. Private browsing isolation, download management, password storage, extension support, reader mode, and settings are planned for subsequent milestones.

## Arch Linux dependencies

```bash
sudo pacman -S --needed base-devel rust gtk4 webkitgtk-6.0
```

If your Arch mirror uses a different package naming snapshot, search the package database for `webkitgtk-6.0`.

## Build and run

```bash
git clone YOUR_REPOSITORY_URL
cd safare-browser
cargo build --release
cargo run --release
```

To install the desktop launcher after building:

```bash
install -Dm644 safare.desktop ~/.local/share/applications/safare.desktop
update-desktop-database ~/.local/share/applications 2>/dev/null || true
```

The executable is created at:

```text
target/release/safare
```

## User data

Safarе stores data under:

```text
~/.local/share/safare/
```

- `bookmarks.txt`
- `history.txt`

## Notes

- GTK4 and WebKitGTK development libraries must be installed before building.
- The first build downloads Rust dependencies from crates.io.
- WebKitGTK is a system dependency; it is not bundled into the executable.
- Use a current Arch Linux installation and keep WebKitGTK updated for security fixes.

## License

MIT. WebKitGTK and its dependencies retain their own licenses.
