#!/usr/bin/env bash
set -euo pipefail
sudo pacman -S --needed base-devel rust gtk4 webkitgtk-6.0
cargo build --release
install -Dm755 target/release/safare "$HOME/.local/bin/safare"
echo "Safarе installed to ~/.local/bin/safare"
