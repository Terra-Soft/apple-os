use gio::prelude::*;
use gtk::prelude::*;
use std::{cell::RefCell, fs, path::PathBuf, rc::Rc};
use webkit::prelude::*;

const APP_ID: &str = "org.appleos.Safare";
const HOME_PAGE: &str = "https://duckduckgo.com/";

fn data_dir() -> PathBuf {
    let mut path = dirs::data_local_dir().unwrap_or_else(|| PathBuf::from("."));
    path.push("safare");
    let _ = fs::create_dir_all(&path);
    path
}

fn normalize_address(input: &str) -> String {
    let value = input.trim();
    if value.is_empty() {
        return HOME_PAGE.to_string();
    }
    if value.contains(' ') || (!value.contains('.') && !value.starts_with("localhost")) {
        return format!("https://duckduckgo.com/?q={}", value.replace(' ', "+"));
    }
    if value.starts_with("http://") || value.starts_with("https://") || value.starts_with("file://") {
        value.to_string()
    } else {
        format!("https://{value}")
    }
}

fn current_webview(notebook: &gtk::Notebook) -> Option<webkit::WebView> {
    let page = notebook.current_page()?;
    notebook.nth_page(Some(page))?.downcast::<webkit::WebView>().ok()
}

fn add_tab(notebook: &gtk::Notebook, address: &str, address_bar: &gtk::Entry) {
    let view = webkit::WebView::new();
    view.set_hexpand(true);
    view.set_vexpand(true);

    let label = gtk::Label::new(Some("New Tab"));
    let page = notebook.append_page(&view, Some(&label));
    notebook.set_tab_reorderable(&view, true);
    notebook.set_current_page(Some(page));

    let address_bar_clone = address_bar.clone();
    let label_clone = label.clone();
    view.connect_load_changed(move |webview, event| {
        if event == webkit::LoadEvent::Committed {
            if let Some(uri) = webview.uri() {
                address_bar_clone.set_text(&uri);
                let title = webview.title().map(|s| s.to_string()).unwrap_or_else(|| "Safarе".to_string());
                label_clone.set_text(&title.chars().take(18).collect::<String>());
                let mut history = data_dir();
                history.push("history.txt");
                let line = format!("{}\t{}\n", title.replace('\n', " "), uri);
                use std::io::Write;
                if let Ok(mut file) = fs::OpenOptions::new().create(true).append(true).open(history) {
                    let _ = file.write_all(line.as_bytes());
                }
            }
        }
    });

    view.load_uri(address);
}

fn build_ui(app: &gtk::Application) {
    let window = gtk::ApplicationWindow::builder()
        .application(app)
        .title("Safarе")
        .default_width(1280)
        .default_height(820)
        .build();

    let root = gtk::Box::new(gtk::Orientation::Vertical, 0);
    root.add_css_class("browser-root");

    let toolbar = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    toolbar.set_margin_top(10);
    toolbar.set_margin_bottom(8);
    toolbar.set_margin_start(12);
    toolbar.set_margin_end(12);
    toolbar.add_css_class("toolbar");

    let back = gtk::Button::from_icon_name("go-previous-symbolic");
    back.set_tooltip_text(Some("Go Back"));
    let forward = gtk::Button::from_icon_name("go-next-symbolic");
    forward.set_tooltip_text(Some("Go Forward"));
    let reload = gtk::Button::from_icon_name("view-refresh-symbolic");
    reload.set_tooltip_text(Some("Reload"));
    let home = gtk::Button::from_icon_name("go-home-symbolic");
    home.set_tooltip_text(Some("Home"));

    let address = gtk::Entry::new();
    address.set_hexpand(true);
    address.set_placeholder_text(Some("Search or enter website address"));
    address.add_css_class("address-entry");

    let bookmark = gtk::Button::from_icon_name("star-new-symbolic");
    bookmark.set_tooltip_text(Some("Bookmark this page"));
    let new_tab = gtk::Button::from_icon_name("tab-new-symbolic");
    new_tab.set_tooltip_text(Some("New Tab"));

    toolbar.append(&back);
    toolbar.append(&forward);
    toolbar.append(&reload);
    toolbar.append(&home);
    toolbar.append(&address);
    toolbar.append(&bookmark);
    toolbar.append(&new_tab);

    let notebook = gtk::Notebook::new();
    notebook.set_scrollable(true);
    notebook.set_show_border(false);
    notebook.set_show_tabs(true);
    notebook.set_vexpand(true);

    let status = gtk::Label::new(Some("Safarе · Ready"));
    status.set_xalign(0.0);
    status.set_margin_start(14);
    status.set_margin_end(14);
    status.set_margin_top(5);
    status.set_margin_bottom(7);
    status.add_css_class("status");

    root.append(&toolbar);
    root.append(&notebook);
    root.append(&status);
    window.set_child(Some(&root));

    {
        let notebook = notebook.clone();
        let address = address.clone();
        back.connect_clicked(move |_| {
            if let Some(view) = current_webview(&notebook) {
                if view.can_go_back() { view.go_back(); }
            }
            address.grab_focus();
        });
    }
    {
        let notebook = notebook.clone();
        forward.connect_clicked(move |_| {
            if let Some(view) = current_webview(&notebook) {
                if view.can_go_forward() { view.go_forward(); }
            }
        });
    }
    {
        let notebook = notebook.clone();
        reload.connect_clicked(move |_| {
            if let Some(view) = current_webview(&notebook) { view.reload(); }
        });
    }
    {
        let notebook = notebook.clone();
        let address = address.clone();
        home.connect_clicked(move |_| {
            if let Some(view) = current_webview(&notebook) {
                view.load_uri(HOME_PAGE);
                address.set_text(HOME_PAGE);
            }
        });
    }
    {
        let notebook = notebook.clone();
        let address = address.clone();
        address.connect_activate(move |entry| {
            let uri = normalize_address(&entry.text());
            entry.set_text(&uri);
            if let Some(view) = current_webview(&notebook) { view.load_uri(&uri); }
        });
    }
    {
        let notebook = notebook.clone();
        let address = address.clone();
        let status = status.clone();
        bookmark.connect_clicked(move |_| {
            if let Some(view) = current_webview(&notebook) {
                if let Some(uri) = view.uri() {
                    let mut path = data_dir();
                    path.push("bookmarks.txt");
                    use std::io::Write;
                    if let Ok(mut file) = fs::OpenOptions::new().create(true).append(true).open(path) {
                        let title = view.title().unwrap_or_else(|| uri.clone());
                        let _ = writeln!(file, "{}\t{}", title.replace('\n', " "), uri);
                        status.set_text("Bookmark saved");
                    }
                }
            }
            address.grab_focus();
        });
    }
    {
        let notebook = notebook.clone();
        let address = address.clone();
        new_tab.connect_clicked(move |_| add_tab(&notebook, HOME_PAGE, &address));
    }
    {
        let notebook = notebook.clone();
        let address = address.clone();
        notebook.connect_switch_page(move |_, page, _| {
            if let Ok(view) = page.clone().downcast::<webkit::WebView>() {
                if let Some(uri) = view.uri() { address.set_text(&uri); }
            }
        });
    }

    add_tab(&notebook, HOME_PAGE, &address);

    let provider = gtk::CssProvider::new();
    provider.load_from_data(include_str!("../data/style.css"));
    gtk::style_context_add_provider_for_display(
        &gtk::gdk::Display::default().expect("No display available"),
        &provider,
        gtk::STYLE_PROVIDER_PRIORITY_APPLICATION,
    );

    window.present();
}

fn main() {
    let app = gtk::Application::builder()
        .application_id(APP_ID)
        .flags(gio::ApplicationFlags::NON_UNIQUE)
        .build();
    app.connect_activate(build_ui);
    app.run();
}
